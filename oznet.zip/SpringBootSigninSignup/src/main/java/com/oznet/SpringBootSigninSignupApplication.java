package com.oznet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSigninSignupApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSigninSignupApplication.class, args);
	}

}
